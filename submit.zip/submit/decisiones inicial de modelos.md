#Decisiones de diseño:

## **Herramientas:** 
	OpenCode 2 como entorno de agentes, y OpenSpec (esquema `spec-driven`, perfil `core`, documentos en inglés) en lugar de Spec Kit. Build usa GLM 5.2 vía Scaleway, y el arquitecto usa MiMo-V2.6-Pro vía Xiaomi, con pago por uso prepagado en vez del Token Plan.
## **Flujo de trabajo:**
  1. Diseño con Opus.
  2. `/opsx-propose` con el arquitecto.
  3. Validación con el CLI de OpenSpec y revisión con Opus.
  4. `/opsx-apply` con Build.
  5. `/opsx-archive`, solo después de implementar.
  
Antes de cada `/opsx:propose`, cierras el diseño en el chat con Opus. Si los cambios 1 o 2 generan un tasks.md demasiado largo, se dividen en dos.

## **Stack del frontend:** 
	Next.js 16 con App Router, React 19, TypeScript, Tailwind 4 (tokens en `@theme` de `src/app/styles/globals.css`), ESLint 9 (sin actualizar hasta que `eslint-config-next` admita la 10) y npm.
## **Arquitectura:** 
	Feature-Sliced Design. Las rutas de Next.js van en `app/` de la raíz y solo enrutan; `pages/` de la raíz queda vacía; las capas van en `src/`, con importación solo hacia abajo. Cada componente se divide en una parte genérica (`shared/ui`) y una parte de negocio (en la capa dueña de sus datos).
## **OpenSpec:**
  - Un cambio por historia de usuario, y capacidades por área del sistema.
  - Los primeros cambios son tokens y tema, y después componentes base.
  - La agrupación de capacidades por User Story Mapping queda para el final.


## **Reparto de instrucciones:**
  - `AGENTS.md`: lo que el agente debe saber siempre.
  - `config.yaml`: un `context` mínimo y reglas por documento.
  - Skill `fsd-architecture`: el detalle de FSD que no está en otro sitio.
  - Archivos de agente: solo cabecera (modelo y permisos), con el cuerpo vacío para conservar el prompt base. El arquitecto solo edita `openspec/`.
## **Contrato de la API:** 
	una copia en `contracts/openapi.yaml`, que el agente nunca edita. Los tipos se generan con `openapi-typescript` en `src/shared/api/schema.ts`, y los alias se exportan desde `src/shared/api/index.ts`.
	
	### Implicacion de rediseño back-end:
	- **API (ofertas):** `sensoryTaxonomy` y `cataConcordance` se devuelven con la misma forma: una lista de raíces con sus `children`, sin `groupBy`. Salen de las relaciones `sensoryTastes` y `cataTastes`, filtradas con el scope `roots`.

## **Tests:** 
	Vitest con React Testing Library desde ya, ejecutados con `npm run test:run`; Playwright, más adelante, como batería previa al despliegue.

## Reglas de `config.yaml`**

- **`context`** All artifacts are written in English.
- **`proposal`:**
    - Reuse an existing capability before creating a new one.
    - Always include an explicit out-of-scope (non-goals) section.
    - A change is described by one verb and one object (e.g. "add login") and must fit in a single implementation session. If it needs "and", split it.
- **`specs`:**
    - Describe observable behavior only. Never name components, libraries or implementation details.
    - Every screen or interaction covers loading, empty, success and error states.
    - Include error scenarios, not only the happy path.
    - Every piece of data shown in the UI maps to a real field of the API (OpenAPI spec).
- **`design`:**
    - List every API endpoint consumed with method, path, auth, request, response and errors.
    - Define TypeScript types for API responses before any component.
    - Explain how each API error is presented to the user.    
    - List the routes, components and files created or modified, each with its full path and its Feature-Sliced Design layer (app, pages, widgets, features, entities, shared). Next.js route files go in the root app/ folder and only import screens from src/pages/.
    - When a feature uses the shared card, map which API field fills each card section.
- **`tasks`:**
    - The first task group creates the API types.
    - Write tests before the implementation they cover.
    - Organize tasks by complete vertical slices (data to screen), not by technical layer.
    - Mark a task complete only after verifying it.

## ** Reglas de `AGENTS.md` (agente Build)**

	**Project**

	- tazavera-front is the web frontend for an existing Laravel REST API.
	- Stack: Next.js 16 (App Router, Turbopack), React 19, TypeScript 5, Tailwind CSS 4, ESLint 9. Package manager: npm.
	- Source code lives under `src/`. The import alias `@/*` maps to `src/*`.
	- Tailwind CSS 4: design tokens are defined with `@theme` in `src/app/globals.css`. There is no `tailwind.config` file; never create one.
	- Planned work is described in `openspec/` (specs and changes). Follow it.
	- Tailwind CSS 4: design tokens are defined with `@theme` in `src/app/styles/globals.css`. There is no `tailwind.config` file; never create one.

	**Architecture (Feature-Sliced Design)**

	- Root `app/` is Next.js routing only. Each `page.tsx` imports its screen from `src/pages/` and contains no logic.
	- Root `pages/` is intentionally empty. Never add files to it.
	- Application code lives in `src/`, organized in FSD layers, from top to bottom: `app`, `pages`, `widgets`, `features`, `entities`, `shared`.
	- A layer may only import from layers below it. Never import upwards or between slices of the same layer.
	- Before designing a change or creating files under `app/` or `src/`, load the `fsd-architecture` skill.

	**API contract**

	- The API is documented with Scribe (OpenAPI 3.0.3). This project consumes the API and never modifies it.
	- Never invent API fields, UI states or error formats. Everything must trace back to the OpenAPI spec or the specs of the current change.
	- The API contract is `contracts/openapi.yaml`, a copy of the backend's Scribe spec. It is the only source of truth for API endpoints, fields and error formats.
	- Never edit `contracts/openapi.yaml`. If it looks outdated or incomplete, stop and tell the user.
	- API types are generated into `src/shared/api/schema.ts` with `npm run types:api`. Never edit that file by hand; regenerate it whenever `contracts/openapi.yaml` changes. Import API types only from `src/shared/api/`.

	**Testing**

	- Unit and component tests use Vitest with React Testing Library. Run them with `npm run test:run`.
	- Async Server Components cannot be tested with Vitest; keep them thin and move logic into testable components or functions.
	- End-to-end tests (Playwright) come later, as a pre-deployment suite.

	**Dependencies**

	- Do not add, remove or upgrade dependencies without explicit approval from the user.
	- Keep ESLint on v9: the plugins in `eslint-config-next` do not support ESLint 10 yet.

## Project Skills

	- ** fsd-architecture**: Feature-Sliced Design details for tazavera-front. Use when deciding in which layer or slice a file goes, creating a new slice, or writing imports between slices. Complements the architecture rules in AGENTS.md.

## AGENTS

	- **architect**: 
		- description: Designs changes with OpenSpec (/opsx-propose). Writes only inside openspec/.
		- mode: primary
		- model: xiaomi/mimo-v2.6-pro.
		
	- **OpenCode-Build**:
		- model: scaleway/glm-5.2

## ** Reglas para definir funcionalidades**

	- **Agrupación con User Story Mapping (pendiente de confirmar):** cada actividad del usuario es una capacidad, y cada historia, un cambio.
	- **Una funcionalidad nueva amplía una capacidad existente** si pertenece a esa área; solo crea una capacidad nueva si el área no existe.
	- **Componentes:**
	  - Los compartidos, en `ui`.
	  - Los propios de una funcionalidad, en su cambio.
	  - Un componente pasa a `ui` cuando lo reutiliza una segunda funcionalidad.
	  - La tarjeta es la excepción: se define de entrada en `ui`.
	- **Tipos:** se generan desde `public/docs/openapi.yaml` (Scribe, OpenAPI 3.0.3). Antes, regeneras la especificación con `php artisan scribe:generate`.
	- **Validación:** `openspec validate` comprueba el formato, y tu revisión con Opus comprueba las reglas. Las reglas no las valida el CLI.
	
	| # | Cambio | Capacidad | Qué define |
	|---|---|---|---|
	| 1 | Tokens y tema | `ui` | design.md: colores, tipografía, espaciado, herramienta de estilos y aplicación del tema. spec.md: solo lo observable (activación del tema si existe, contraste). |
	| 2 | Componentes básicos | `ui` | design.md: componentes base y la tarjeta compuesta con sus secciones (estado, cabecera, detalles, puntuación, acciones) y cuáles son opcionales. spec.md: comportamiento (sección sin datos, acciones deshabilitadas). |
	| 3 en adelante | Historias de usuario | Una por actividad del usuario (**pendiente**) | Un cambio por historia, que usa la tarjeta y los componentes base. |
	  


**5. Pendientes**

- Confirmar la agrupación por actividades de usuario.
- Decidir si se usan wireframes con MiMo (multimodal).

## Notas de implementacion:

- **Red:** la red de la escuela bloquea la API de Xiaomi, así que las sesiones con MiMo se hacen con datos móviles.